# Experimental modeling dataset (`cfb_864.csv`)

The CSV contains **864 local, calibrated, time-averaged solids-holdup targets** from the two-dimensional circulating fluidized bed riser experiments cited as Xu and Zhu (2010, 2011) in the manuscript. The submitting author states that the compiled records are available from a dissertation and may be shared in the response package. The complete author-supplied citation is recorded in `../docs/DATA_SOURCE.md`. Do not claim a particular thesis edition or license without verifying it.

This CSV is the **model-ready observation table**, not raw 100 kHz optical-probe waveforms or calibration files. Values of solids holdup are not normalized; any model input/target Min–Max transformations are learned from training data only. There are 16 complete particle-system/operating-condition combinations and 54 spatial positions per combination, plus a stable `order` index (1–864). The file has 17 historical columns, of which five auxiliary indicator columns `E,F,G,I,J` are retained but **not used** in the published four model definitions.

- DNE inputs: `SMD,LP,H,Ug,Gs` (5 dimensions).
- Reduced dummy/OHE inputs: `A,B,C,D,LP,H,Ug,Gs` (8 dimensions; FCC is the all-zero reference class).
- Target: `εs`, local solids holdup (dimensionless).
- Material code: `Materials` values 0 (FCC), 1/2/3 (glass beads), 4 (sand).
- Spatial variables: `H` (m) and `LP` (signed lateral normalized position y/Y).
- Operating variables: `Ug` (m/s), `Gs` (kg/(m²·s)).

## Integrity

- 864 observation records; 864 unique `order` IDs; 16 complete fields × 54 observations.
- SHA-256 of `data/cfb_864.csv`: `907f056137bbce008f1b14a21b1e916023fb854d84107f895404f9d4f990087c`
- The associated `split_ids/` files specify original 778/86 pointwise train/test IDs.

## Source and release note

Cite the original Xu–Zhu experimental papers as in the manuscript and the dissertation once its full reference is provided. The submitting author has indicated that the compiled dataset may be shared. **A thesis being publicly readable does not itself establish blanket redistribution rights**; before hosting this candidate ZIP publicly, the authors must verify the source rights or permissions and choose appropriate licensing terms. No claim is made to release original probe signals or independently acquired experimental data.
