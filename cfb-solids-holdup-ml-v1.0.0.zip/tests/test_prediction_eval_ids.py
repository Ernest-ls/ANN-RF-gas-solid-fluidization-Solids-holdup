"""The public evaluation helper must never silently score all data when no test IDs are given."""
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]

def test_predict_cli_documents_eval_ids():
    completed=subprocess.run([sys.executable,str(ROOT/'scripts/predict_model.py'),'--help'],capture_output=True,text=True,check=True)
    assert '--eval-ids' in completed.stdout
