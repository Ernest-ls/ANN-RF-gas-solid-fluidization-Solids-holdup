"""Check that the documented fixed configurations lie inside the supplied Optuna domains.

This test does not execute the 200-trial search or verify the historical search trajectory.
"""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from cfb_repro.core import ANN_PARAMS,RF_PARAMS,FEATURES

def test_architectures_and_optima_within_search_bounds():
    assert len(FEATURES['dne']) == 5
    assert len(FEATURES['ohe_reduced']) == 8
    for p in ANN_PARAMS.values():
        assert 2 <= len(p['hidden']) <= 8
        assert all(32 <= n <= 256 for n in p['hidden'])
        assert 1e-5 <= p['lr'] <= 1e-1
        assert 0 <= p['dropout'] <= .2
        assert 16 <= p['batch_size'] <= 64
        assert p['activation'] in ['relu','gelu']
        assert p['optimizer'] in ['adamw','adam','sgd']
    for p in RF_PARAMS.values():
        assert 32 <= p['n_estimators'] <= 256
        assert 2 <= p['max_depth'] <= 30
        assert 2 <= p['min_samples_split'] <= 100
        assert 1 <= p['min_samples_leaf'] <= 20
        assert p['max_features'] in ['sqrt','log2',None]
        assert p['bootstrap'] in [True,False]

def test_modeling_dataset_group_structure():
    import csv
    from collections import Counter
    p=Path(__file__).resolve().parents[1]/'data'/'cfb_864.csv'
    with p.open(encoding='utf-8',newline='') as f:rows=list(csv.DictReader(f))
    assert len(rows)==864
    assert len({int(r['order']) for r in rows})==864
    assert Counter(Counter((r['Materials'],r['Ug'],r['Gs']) for r in rows).values())=={54:16}
