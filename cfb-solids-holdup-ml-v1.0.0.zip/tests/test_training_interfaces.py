import sys
from pathlib import Path
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from cfb_repro.core import feature_frame,metrics,fit_rf_predict,build_ann
from cfb_repro.train import train_ann_predict

def fake_data(n=80):
    rng=np.random.default_rng(124)
    mat=np.tile(np.arange(5),n//5)
    cols={'order':np.arange(n)+1,'Materials':mat,'A':(mat==1).astype(int),'B':(mat==2).astype(int),
          'C':(mat==3).astype(int),'D':(mat==4).astype(int),
          'SMD':np.choose(mat,[67,76,134,288,138]),'LP':rng.uniform(-.98,.98,n),
          'H':rng.uniform(1.27,6.35,n),'Ug':rng.uniform(3.5,8,n),
          'Gs':rng.choice([50,100,150,200],n)}
    df=pd.DataFrame(cols)
    df['εs']=(.03+.02*(df['Materials']==0)+.04*(1-df['H']/8)+.015*(1-df['LP'].abs())+rng.normal(0,.001,n)).clip(0,1)
    return df

def test_encoding_dimensions():
    df=fake_data()
    assert feature_frame(df,'dne').shape[1]==5
    assert feature_frame(df,'ohe_reduced').shape[1]==8
    assert build_ann('ohe_reduced')[0].in_features==8

def test_metrics_exact():
    vals=metrics([1,2,3],[1,2,3])
    assert vals['R2']==1 and vals['MAE']==0 and vals['RMSE']==0

def test_rf_train_predict():
    df=fake_data()
    pr,_,sx=fit_rf_predict(df.iloc[:60],df.iloc[60:],'dne')
    assert len(pr)==20 and np.isfinite(pr).all()
    assert sx.n_features_in_==5

def test_ann_train_predict_and_eval():
    df=fake_data()
    pars={'lr':.001,'hidden':[16,12],'dropout':.05,'batch_size':20,'optimizer':'adamw','activation':'relu'}
    pr,model,sx,sy,_=train_ann_predict(df.iloc[:60],df.iloc[60:],'dne',params=pars,epochs=3,seed=42)
    assert len(pr)==20 and np.isfinite(pr).all() and not model.training
