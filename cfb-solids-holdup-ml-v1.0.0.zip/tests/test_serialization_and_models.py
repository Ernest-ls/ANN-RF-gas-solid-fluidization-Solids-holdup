import sys
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from cfb_repro.serialization import serialize_scaler,transform_with_saved_scaler,inverse_transform_with_saved_scaler

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from predict_model import predict


def test_json_scaler_matches_sklearn():
    arr=np.array([[1.,2.],[3.,4.],[5.,2.]])
    scaler=MinMaxScaler().fit(arr)
    record=serialize_scaler(scaler)
    assert np.allclose(transform_with_saved_scaler(arr,record),scaler.transform(arr))
    assert np.allclose(inverse_transform_with_saved_scaler(scaler.transform(arr),record),arr)


def test_all_four_shipped_checkpoints_load():
    # This is an inference smoke test only, NOT a substitute for experimental validation.
    frame=pd.DataFrame([{'A':0,'B':0,'C':0,'D':0,'SMD':67,'LP':0,
                         'H':3.30,'Ug':5.5,'Gs':100}])
    for name in ['dne_ann','ohe_ann','dne_rf','ohe_rf']:
        yp=predict(name,frame,ROOT/'trained_models')
        assert yp.shape==(1,)
        assert np.isfinite(yp).all()
