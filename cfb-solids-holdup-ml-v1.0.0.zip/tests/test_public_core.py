import sys
from pathlib import Path
import pandas as pd
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
from cfb_repro.core import metrics,feature_frame

def test_smoke_core():
 df=pd.DataFrame({'Materials':[0,1,2,3,4],'A':[0,1,0,0,0],'B':[0,0,1,0,0],'C':[0,0,0,1,0],'D':[0,0,0,0,1],
 'SMD':[67,76,134,288,138],'LP':[0.]*5,'H':[2.]*5,'Ug':[5.5]*5,'Gs':[100]*5,'εs':[.01,.02,.03,.04,.05]})
 assert len(feature_frame(df,'dne').columns)==5
 assert len(feature_frame(df,'ohe_reduced').columns)==8
 assert metrics([0,.5,1],[0,.5,1])['MAE']==0
