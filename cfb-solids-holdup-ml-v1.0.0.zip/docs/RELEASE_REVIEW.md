# Release review

2026-11-25. Archive integrity and 42 original file hashes passed. Dataset has 864 unique observation IDs across 16 groups of 54 rows. Python syntax checks passed. All 10 supplied tests passed in Python 3.10. Installed scikit-learn 1.7.2 emits version warnings for RF artifacts saved with 1.8.0. Use the original scikit-learn 1.8.0 environment for checkpoint reproduction. Full historical Optuna search and dissertation Appendix B1 correspondence were not independently verified.
