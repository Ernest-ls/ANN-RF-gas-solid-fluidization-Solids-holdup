# Model hyperparameter values and Optuna search bounds

The trained model configurations have been recovered from historical fixed-training scripts. The Optuna code in `scripts/optuna_search.py` provides the bounds below. All documented fixed optimal model configurations fall within these bounds. This **does not** imply the original Optuna optimization trial history was recovered or that running this new grouped objective selects identical optima.

## ANN

| Search parameter | Search domain | DNE-ANN | OHE-ANN |
|---|---|---|---|
| `lr` | log-uniform 1e−5 to 1e−1 | 0.00036 | 0.00078 |
| `n_layers` | integer 2–8 | 4 | 5 |
| `n_units_i` | integer 32–256, each layer | [207,247,249,36] | [174,202,146,232,202] |
| `dropout` | 0.0–0.2 | 0.05328 | 0.02668 |
| `batch_size` | integer 16–64 | 58 | 54 |
| `activation` | ReLU or GELU | ReLU | ReLU |
| `optimizer` | AdamW, Adam, SGD | AdamW | AdamW |

Fixed training parameters `weight_decay=0.01`, `seed=42`, `epochs=500` and early-stop patience 100 are not selected as Optuna search dimensions in this prospective script.

## Random forest

| Search parameter | Search domain | DNE-RF | OHE-RF |
|---|---|---|---|
| `n_estimators` | 32–256 | 110 | 162 |
| `max_depth` | 2–30 | 17 | 25 |
| `min_samples_split` | 2–100 | 5 | 5 |
| `min_samples_leaf` | 1–20 | 1 | 1 |
| `max_features` | sqrt, log2, None | sqrt | log2 |
| `bootstrap` | True/False | False | False |

Fixed RF `random_state=42` is not an Optuna search dimension.

**Eight-dimensional OHE representation:** four A–D indicators plus `LP,H,Ug,Gs`.
