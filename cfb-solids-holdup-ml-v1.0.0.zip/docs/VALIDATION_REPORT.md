# Four-model retraining verification — 24 November 2026

## Scope and method

- Dataset: author-supplied 864-row modeling compilation, included as `data/cfb_864.csv` in the present author-approved public-release candidate.
- Split: archived original `order` IDs, 778 train / 86 held-out test, **point-level**.
- Hyperparameters: fixed values extracted from archived test/train scripts. The original Optuna optimization run and its complete study history were not re-run or validated.
- ANN settings: 500 maximum epochs, fixed seed 42, Xavier normal initializations, AdamW, MinMax on training features and targets, early stopping based on training loss. Deterministic inference with `model.eval()`.
- RF settings: original n_estimators, max_depth, max_features, min_samples_split, bootstrap and random_state; scaler fitted on training features only.
- Each model was freshly trained and scored. No pretrained models were loaded **during training**. Four NEW checkpoints, the ANN preprocessing JSON and RF estimator/scaler bundles are included in the reviewer release candidate. The 864-row model-ready input table is bundled. Individual historical test predictions and the original probe waveforms are not included. Newly trained checkpoints and reloading checks are provided.

## New result versus submitted Table 7

| Model | Submitted R² | New R² | Submitted RMSE | New RMSE | New MAE | New SMAPE (%) |
|---|---:|---:|---:|---:|---:|---:|
| DNE-ANN | 0.917 | 0.957385 | 0.0080 | 0.005768 | 0.004228 | 10.811 |
| OHE-ANN | 0.968 | 0.974022 | 0.0050 | 0.004504 | 0.003236 | 8.084 |
| DNE-RF | 0.929 | 0.929172 | 0.0074 | 0.007436 | 0.005341 | 14.473 |
| OHE-RF | 0.938 | 0.938217 | 0.0069 | 0.006945 | 0.004984 | 14.128 |

**Why ANN metrics differ:** The archived scripts ran predictions in a way that could leave Dropout active; this release explicitly switches the model into evaluation mode. Training seeds, random initialization and framework versions can also influence outcomes. These new values are not claimed as the paper's historical Table 7 results, and they should not replace the paper's results without a separately documented manuscript revision.

### Independently reloaded checkpoints

After retraining, each of the four saved checkpoints was reloaded using `scripts/predict_model.py`. All 86 withheld predictions agree with the direct training-script output: maximum absolute differences of 5.91 × 10⁻⁹ (DNE-ANN), 8.06 × 10⁻⁹ (OHE-ANN), and 9.71 × 10⁻¹⁷ (each RF). See `verification/checkpoint_reload_verification.csv` and `verification/checkpoint_sha256.csv`. The ANN reload uses `torch.load(..., weights_only=True)`; RF joblib bundles must only be loaded from trusted sources.

### RF consistency check

The freshly fitted DNE-RF and OHE-RF implementations reproduce the archived 86 test predictions to floating point precision (~2.8 × 10⁻17 maximum absolute difference, checked in the internal forensic audit). This is stronger evidence than merely matching the rounded R².

### Verification of code interfaces

`pytest -q tests` passed **9 tests** (including validation of the bundled 864-row data structure and fixed hyperparameters within Optuna search bounds), in addition to ANN/RF training and inference tests. The same command-line training program was run independently with all four model choices. The Optuna script was only syntax-compiled, as requested, **not** fully executed or validated here.

## Limits

1. The test protocol is pointwise, so it can include positions from the same operating field in both training and test. It does **not** establish complete-field generalization.
2. The archived OHE uses four dummy variables, making its ANN input 8-dimensional, not the nine dimensions described in the submitted paper.
3. Historical Table 8 values remain unresolved; no claim of exact five-fold reproduction is made.
4. The modeling-ready dataset is included at the author’s direction; the full source dissertation citation and redistribution/license terms must be verified before its public hosting.
